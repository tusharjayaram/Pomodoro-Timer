import React, {Component, useState} from 'react';
import { TextInput, ScrollView, Button, StyleSheet, Text, View } from 'react-native';


export default class Timer extends React.Component {

}
